/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Acer
 */
public class Harbinger6th {     
    protected String nama_3061;     
    protected String nip_3061;     
    protected float gajiPokok_3061; 
    public void Tampil_3061(){ 
        System.out.println("Nama: " + nama_3061); 
        System.out.println("NIP: " + nip_3061); 
        System.out.println("Gaji Pokok: " + gajiPokok_3061); 
    } 
} 