/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Acer
 */
public class scaramouche extends Harbinger6th {      
    public scaramouche(){ 
         
    } 
    
public void TampilData_3061(){ 
        System.out.println("Karyawan Penggaji"); 
        Tampil_3061(); 
        System.out.println("Total Gaji: " + gajiPokok_3061); 
    } 
} 

