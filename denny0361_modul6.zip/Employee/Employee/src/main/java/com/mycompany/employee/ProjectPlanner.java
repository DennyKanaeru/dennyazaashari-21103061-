/* 
*	Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license 
*	Click 
nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${pack agePath}/${mainClassName}.java to edit this template 
 */ 
 
package com.mycompany.employee; 
 
import java.io.BufferedReader;import java.io.IOException; 
 import java.io.InputStreamReader; 
 
/** 
 * 
*	@author Acer 
 */ 
public class ProjectPlanner { 
 
    public static void main(String[] args) {        
        scaramouche denny_3061 = new scaramouche();         
        wanderer aza_3061 = new wanderer();         
        shogunPuppet ashari_3061 = new shogunPuppet(); 
         
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));  
      
        try{ 
            System.out.println("Data Pegawai");             
            System.out.print("Nama              : ");             
            denny_3061.nama_3061 = br.readLine(); 
            System.out.print("NIP               : ");             
            denny_3061.nip_3061 = br.readLine();             
            System.out.print("Gaji Pokok        : "); 
            denny_3061.gajiPokok_3061 = Float.parseFloat(br.readLine());             
            System.out.println("");             
            denny_3061.TampilData_3061(); 
            System.out.println(""); 
            System.out.println(""); 
             
            System.out.print("Nama              : ");             
            aza_3061.nama_3061 = br.readLine();             
            System.out.print("NIP               : ");             
            aza_3061.nip_3061 = br.readLine();             
            System.out.print("GajiPokok         : "); 
            aza_3061.gajiPokok_3061 = Float.parseFloat(br.readLine());             
            System.out.print("Komisi            : "); 
            aza_3061.Komisi_3061 = Float.parseFloat(br.readLine());             
            System.out.print("Total Penjualan   : "); 
            aza_3061.TotalPenjualan_3061 = Float.parseFloat(br.readLine());             
            aza_3061.TotalGaji_3061();             
            System.out.println("");             
            aza_3061.TampilData_3061(); 
            System.out.println("");             
            System.out.println(""); 
             
            System.out.print("Nama              : ");             
            ashari_3061.nama_3061 = br.readLine();             
            System.out.print("NIP               : ");             
            ashari_3061.nip_3061 = br.readLine(); 
            System.out.print("Gaji Pokok        : "); 
            ashari_3061.gajiPokok_3061 = Float.parseFloat(br.readLine());             
            System.out.print("Komisi            : "); 
            ashari_3061.Komisi_3061 = Float.parseFloat(br.readLine());             
            System.out.print("Total Hasil Proyek: "); 
            ashari_3061.TotalHslProyek_3061 = Float.parseFloat(br.readLine());             
            ashari_3061.TotalGaji_3061();             
            System.out.println("");             
            ashari_3061.TampilData_3061();            
        } 
         
        catch(IOException | NumberFormatException ex){ 
            System.out.println(ex); 
        } 
    } 
} 
