/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Acer
 */
public class wanderer extends Harbinger6th {      
    public float Komisi_3061;     
    public float TotalPenjualan_3061;     
    public float Totalgaji_3061; 
    String nama_3061;
     
     public wanderer(){ 
         
    } 
     
    public float TotalGaji_3061(){ 
        Totalgaji_3061 = gajiPokok_3061 + (Komisi_3061 * TotalPenjualan_3061);         
        return Totalgaji_3061; 
    } 

    public void TampilData_3061(){ 
        System.out.println("Komisi Karyawan"); 
        Tampil_3061(); 
        System.out.println("Total Gaji: " + Totalgaji_3061); 
    } 
} 
