/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Acer
 */
public class shogunPuppet extends Harbinger6th {     
    public float Komisi_3061;     
    public float TotalHslProyek_3061;     
    public double Totalgaji_3061; 
     
    public shogunPuppet(){ 
         
    }              
    public double TotalGaji_3061(){ 
        Totalgaji_3061 = (gajiPokok_3061 *5/100) - gajiPokok_3061 + (Komisi_3061 * TotalHslProyek_3061);         
        return Totalgaji_3061; 
    } 
        public void TampilData_3061(){ 
        System.out.println("Perancang Proyek"); 
        Tampil_3061(); 
        System.out.println("Total Gaji: " + Totalgaji_3061); 
    } 
} 

